let score = 0;
const ball = document.getElementById("ball");
const scoreDisplay = document.getElementById("score");

function moveBall() {
    const container = document.getElementById("game-container");
    const maxX = container.clientWidth - ball.clientWidth;
    const maxY = container.clientHeight - ball.clientHeight;
    
    const newX = Math.random() * maxX;
    const newY = Math.random() * maxY;
    
    ball.style.left = newX + "px";
    ball.style.top = newY + "px";
}

ball.addEventListener("click", () => {
    score++;
    scoreDisplay.textContent = score;
    moveBall();
});

moveBall();
